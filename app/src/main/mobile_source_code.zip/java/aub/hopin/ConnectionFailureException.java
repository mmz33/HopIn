package aub.hopin;

public class ConnectionFailureException extends Exception {
    public ConnectionFailureException() {}
}
